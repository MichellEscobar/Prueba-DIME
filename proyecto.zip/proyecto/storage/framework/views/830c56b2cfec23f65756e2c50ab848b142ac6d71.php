<h1>Lista de empleados</h1>

//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css

<table class="table table-light">

    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Sexo</th>
            <th>Area</th>
            <th>Descripcion</th>
            <th>Roles</th>
        </tr>
    </thead>


    <tbody>
        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($empleado->id); ?></td>
            <td><?php echo e($empleado->Nombre); ?></td>
            <td><?php echo e($empleado->Correo); ?></td>
            <td><?php echo e($empleado->Sexo); ?></td>
            <td><?php echo e($empleado->Area); ?></td>
            <td><?php echo e($empleado->Descripcion); ?></td>
            <td><?php echo e($empleado->Roles); ?></td>
            <td>Editar | Borrar</td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\proyecto\resources\views/empleado/index.blade.php ENDPATH**/ ?>