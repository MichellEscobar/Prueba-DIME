<h1>Crear empleado</h1>

<br>

<form action="{{ url('/empleado') }}" method="post">
@csrf

<label for="Nombre"> Nombre Completo </label>
<input type="text" name="Nombre" id="Nombre">
<br>
<br>

<label for="Correo"> Correo </label>
<input type="text" name="Correo" id="Correo">
<br>
<br>

<label for="Sexo"> Sexo </label><br>

<input type="radio" name="empleoactual" value="tiempocompleto"> Femenino <br>

<input type="radio" name="empleoactual" value="mediodia"> Masculino <br>
<br>


<label for="Area"> Area </label>


<select name="entradalista1">


<option selected="selected"> Seleccione Area </option>


<option>Administrativo</option>
<option>Asistencial</option>
<option>Gerencial</option>

</optgroup>
</select>

<br>
<br>

<label for="Descripcion"> Descripcion </label>
<input type="text" name="Descripcion" id="Descripcion">
<br>
<label for="Gerente"> Deseo recibir boletin informatico </label>
<input type="checkbox" class="form-check-input"  value="1" {{  1 }}>

<br><br>

<label for="Roles"> Roles </label>
<br>

<label for="profesional"> *Profesional de proyectos - Desarrollo </label>
<input type="checkbox" class="form-check-input"  value="1" >
<br>

<label for="Gerente"> *Gerente estrategico </label>
<input type="checkbox" class="form-check-input"  value="1" {{  1 }}>
<br>

<label for="Auxiliar"> *Auxiliar administrativo </label>
<input type="checkbox" class="form-check-input"  value="1" {{  1 }}>
<br><br>


<input type="submit" value="Guardar">


</form>