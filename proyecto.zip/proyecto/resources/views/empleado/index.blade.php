<h1>Lista de empleados</h1>



<table class="table table-light">

    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Sexo</th>
            <th>Area</th>
            <th>Descripcion</th>
            <th>Roles</th>
        </tr>
    </thead>


    <tbody>
        @foreach( $empleados as $empleado )
        <tr>
            <td>{{ $empleado->id }}</td>
            <td>{{ $empleado->Nombre }}</td>
            <td>{{ $empleado->Correo }}</td>
            <td>{{ $empleado->Sexo }}</td>
            <td>{{ $empleado->Area }}</td>
            <td>{{ $empleado->Descripcion }}</td>
            <td>{{ $empleado->Roles }}</td>
            <td>Editar | Borrar</td>
        </tr>
    @endforeach
    </tbody>
</table>